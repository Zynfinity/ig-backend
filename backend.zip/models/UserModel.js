import { Sequelize } from "sequelize";
import db from "../config/Database.js";

const { DataTypes } = Sequelize;

const Users = db.define('users', {
    id: {
        type: DataTypes.STRING,
        primaryKey: true
    },
    email: {
        type: DataTypes.STRING,
        unique: true
    },
    username: {
        type: DataTypes.STRING,
        unique: true
    },
    firstName: {
        type: DataTypes.STRING
    },
    lastName: {
        type: DataTypes.STRING
    },
    fullName: {
        type: DataTypes.STRING
    },
    bio: {
        type: DataTypes.STRING
    },
    imageUrl: {
        type: DataTypes.STRING
    },
}, {
    freezeTableName: true
});

export default Users;