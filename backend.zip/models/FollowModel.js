import { Sequelize } from "sequelize";
import db from "../config/Database.js";
import Users from "./UserModel.js";
const { DataTypes } = Sequelize;

const Follows = db.define('follows', {
    id: {
        type: DataTypes.INTEGER(20),
        primaryKey: true,
        autoIncrement: true
    },
    follower_id: {
        type: DataTypes.STRING
    },
    followed_id: {
        type: DataTypes.STRING
    }
}, {
    freezeTableName: true
});
Users.hasMany(Follows, { foreignKey: 'follower_id', onDelete: 'CASCADE', as: 'followed' });
Users.hasMany(Follows, { foreignKey: 'followed_id', onDelete: 'CASCADE', as: 'followedBy' });
Follows.belongsTo(Users, { foreignKey: 'follower_id', as: 'Follower' });
Follows.belongsTo(Users, { foreignKey: 'followed_id', as: 'Followed' });
export default Follows;