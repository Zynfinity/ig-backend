import { Sequelize } from "sequelize";
import db from "../config/Database.js";
import Users from "./UserModel.js";

const { DataTypes } = Sequelize;

const Posts = db.define('posts', {
    id: {
        type: DataTypes.STRING,
        primaryKey: true
    },
    user_id: {
        type: DataTypes.STRING
    },
    imageUrl: {
        type: DataTypes.STRING,
    },
    caption: {
        type: DataTypes.TEXT
    }
}, {
    freezeTableName: true
});

// Posts.belongsTo(Users, { foreignKey: 'id', onDelete: 'CASCADE' });
Users.hasMany(Posts, { foreignKey: 'user_id', onDelete: 'CASCADE', as: 'posts' });
Posts.belongsTo(Users, { foreignKey: 'user_id', as: 'user' });
export default Posts;