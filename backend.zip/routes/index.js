import Express from "express";
import webhook from "../controllers/Webhook.js";
import { findUser, getUserList } from "../controllers/Users.js";
import bodyParser from "body-parser";
import cors from "cors";
import upload from "../controllers/Uploader.js";
import { getAllPost, getAllPostFollowed, newPost } from "../controllers/Posts.js";
import path from "path";
import { fileURLToPath } from 'url';
import { Follow } from "../controllers/Follows.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const router = Express.Router();

router.use('/uploads', Express.static(path.join(__dirname, '../uploads')));
router.use(bodyParser.json());
router.use(cors({
    credentials: true,
    origin: ["http://localhost:5173", "https://zynfinity.my.id", "http://127.0.0.1:5500", "https://64wxl4fd-5173.asse.devtunnels.ms"]
}));
router.post('/api/webhook', webhook);
router.post('/api/user/find', findUser);
router.post('/api/user/all', getUserList);
router.post('/api/uploader', upload.single('image'), (req, res) => {
    res.json({ fileName: req.file.filename, filePath: `/uploads/${req.file.filename}` });
});
router.get('/api/post/all', getAllPost);
router.post('/api/post/followed', getAllPostFollowed);
router.post('/api/post/new', newPost);

// 
router.post('/api/user/follow', Follow)
export default router;