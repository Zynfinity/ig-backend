import Express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import db from "./config/Database.js";
const app = Express();
import dotenv from "dotenv";
import router from "./routes/index.js";
dotenv.config();
app.set("json spaces", 2);
app.use(router);
app.use(bodyParser.json());
app.use(cors({
    credentials: true,
    origin: ["http://localhost:5173", "https://zynfinity.my.id", "http://127.0.0.1:5500"]
}));

// Connect db
try {
    await db.authenticate()
    console.log('Database Connected');
    // Follows.sync();
    // Posts.sync();
} catch (e) {
    console.error(e);
}
// Validasi token Login
function accessValidation(req, res, next) {
}

app.get('/', function (req, res) {
    res.status(200).json({
        endpoint: [
            {
                path: '/database/getUsers',
                description: 'get all user'
            },
            {
                path: '/quiz?type=${type}',
                description: 'Get Quiz by type. 1=Math'
            }
        ],
        maintainer: 'FunQUIZ TEAM'
    })
})
app.listen(process.env['PORT'], async () => {
    console.log("Server listening on port " + process.env['PORT']);
});

