import Users from "../models/UserModel.js";
const webhook = async (req, res) => {
    try {
        const event = req.body
        console.log(event);
        const { data, type } = event;
        if (type == 'user.created') {
            const { id, email_addresses: [{ email_address }], username, first_name, last_name, image_url } = data;
            const newUser = await Users.create({
                id: id,
                email: email_address,
                username: username,
                firstName: first_name,
                lastName: last_name,
                fullName: last_name != null ? first_name + ' ' + last_name : first_name,
                bio: null,
                imageUrl: image_url
            });
            console.log('User created:', newUser.toJSON());
            res.json({ status: true })
        }
    } catch (e) {
        console.log(e)
    }
}
export default webhook;