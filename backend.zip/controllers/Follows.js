import { Sequelize } from "sequelize";
import Follows from "../models/FollowModel.js";

const Follow = async (req, res) => {
    try {
        const { follower_id, followed_id, action } = req.body;
        console.log(req.body);
        if (action == 'follow') {
            const follow = await Follows.create({
                id: null,
                follower_id: follower_id,
                followed_id: followed_id
            });
            res.json(follow);
        } else {
            const unfollow = await Follows.destroy({
                where: {
                    followed_id: followed_id
                }
            });
            res.json(unfollow);
        }
    } catch (e) {
        console.log(e);
        res.status(500).json({ status: false, msg: String(e) })
    }
}

export { Follow };