import { Sequelize } from "sequelize";
import Follows from "../models/FollowModel.js";
import Posts from "../models/PostModel.js";
import Users from "../models/UserModel.js";
import db from "../config/Database.js";

const findUser = async (req, res) => {
    const { user_id, my_id } = req.body;
    const find = await Users.findOne({
        where: { id: user_id },
        include: [
            {
                model: Posts,
                as: 'posts'
            },
            {
                model: Follows,
                as: 'followedBy',
                include: [
                    {
                        model: Users,
                        as: 'Follower',
                        attributes: ['id', 'username', 'firstName', 'lastName', 'fullName', 'bio', 'imageUrl']
                    }
                ],
                // attributes: []
            },
            {
                model: Follows,
                as: 'followed',
                include: [
                    {
                        model: Users,
                        as: 'Followed',
                        attributes: ['id', 'username', 'firstName', 'lastName', 'fullName', 'bio', 'imageUrl']
                    }
                ],
            }
        ]
    });
    // res.json(find);
    const rfind = JSON.parse(JSON.stringify(find));
    // Map the followers from the followed array and delete the followed property
    rfind.follower = rfind.followedBy.map(f => f.Follower);
    rfind.followed = rfind.followed.map(f => f.Followed);
    delete rfind.followedBy;
    rfind.isFollowed = rfind.follower.find(f => f.id == my_id) ? true : false;
    rfind.isFollower = rfind.followed.find(f => f.id == my_id) ? true : false;
    res.json(rfind);
}
const getUserList = async (req, res) => {
    const { user_id } = req.body;
    try {
        const users = await Users.findAll({
            where: {
                id: {
                    [Sequelize.Op.ne]: user_id
                }
            },
            include: [
                {
                    model: Posts,
                    as: 'posts'
                },
                {
                    model: Follows,
                    as: 'followedBy',
                    include: [
                        {
                            model: Users,
                            as: 'Follower',
                            attributes: ['id', 'username', 'firstName', 'lastName', 'fullName', 'bio', 'imageUrl']
                        }
                    ],
                    // attributes: []
                },
                {
                    model: Follows,
                    as: 'followed',
                    include: [
                        {
                            model: Users,
                            as: 'Followed',
                            attributes: ['id', 'username', 'firstName', 'lastName', 'fullName', 'bio', 'imageUrl']
                        }
                    ],
                }
            ]
        });
        if (!users) return res.status(404).json({
            status: false,
            msg: 'User not found!'
        });
        const rusers = JSON.parse(JSON.stringify(users));

        // console.log(rusers);
        for (let i of rusers) {
            // Map the followers from the followed array and delete the followed property
            i.follower = i.followedBy.map(f => f.Follower);
            i.followed = i.followed.map(f => f.Followed);
            delete i.followedBy;
            i.isFollowed = i.follower.find(f => f.id == user_id) ? true : false;
            i.isFollower = i.followed.find(f => f.id == user_id) ? true : false;
        }
        res.json(rusers);
    } catch (e) {
        console.log(e);
        return res.status(404).json({
            status: false,
            msg: 'User not found!'
        });
    }
}
export { findUser, getUserList }