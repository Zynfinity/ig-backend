import { Sequelize, where } from "sequelize";
import Follows from "../models/FollowModel.js";
import Posts from "../models/PostModel.js";
import Users from "../models/UserModel.js";

const getAllPost = async (req, res) => {
    const id = req.query.id;
    console.log(id);
    const posts = await Posts.findAll(id && {
        where: {
            id: id
        }
    });
    res.json(posts);
}
const newPost = async (req, res) => {
    const { id, user_id, imageUrl, caption } = req.body;
    const newPost = await Posts.create({
        id: id,
        user_id: user_id,
        imageUrl: imageUrl,
        caption: caption
    });
    console.log('Post Created', newPost.toJSON());
    res.json({ status: true });
}
const getAllPostFollowed = async (req, res) => {
    try {
        const { user_id } = req.body;
        const fetchPost = await Posts.findAll({
            where: {
                user_id: {
                    [Sequelize.Op.ne]: user_id // Not equal to 1
                }
            },
            include: [{
                model: Users,
                as: 'user',
                include: {
                    model: Follows,
                    as: 'followedBy',
                    where: {
                        follower_id: user_id
                    }
                }
            }]
        })
        const filteredPosts = fetchPost.filter(post => post.user !== null);
        if (filteredPosts.length == 0) {
            return res.status(404).json({
                status: false,
                msg: 'Tidak ada Postingan'
            })
        }
        res.json(filteredPosts);
    } catch (e) {
        console.log(e);
        res.status(505).json({
            status: false,
            msg: String(e)
        });
    }
}
export { getAllPost, newPost, getAllPostFollowed };